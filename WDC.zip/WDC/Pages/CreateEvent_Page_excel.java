package WDC.Pages;

import javafx.scene.control.Cell;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hwpf.usermodel.DateAndTime;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CreateEvent_Page_excel {
    WebDriver driver;
    XSSFWorkbook workbook;
    XSSFSheet sheet;
    XSSFCell cell;

    public CreateEvent_Page_excel(WebDriver driver) {
        this.driver = driver;
    }

    //Xpath of all control
    By btncreateevent = By.xpath("//span[contains(text(),'Create Event')]");

    public void btncreateevent() {

        driver.findElement(btncreateevent).click();

    }

    public void ReadData() throws IOException, InterruptedException {

// Import excel sheet.
        // Import excel sheet.
        File src = new File("D:\\Automation\\Automation_Practice\\Basic_Automation\\src\\WDC\\Data\\Test.xlsx");
        // Load the file.
        FileInputStream fis = new FileInputStream(src);
        System.out.println(fis);
        // Load he workbook.
        workbook = new XSSFWorkbook(fis);
        System.out.println(workbook);
        // Load the sheet in which data is stored.
        sheet = workbook.getSheet("Sheet1");
        //System.out.println(sheet);

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			/*I have added test data in the cell A2 as "testemailone@test.com" and B2 as "password"
			Cell A2 = row 1 and column 0. It reads first row as 0, second row as 1 and so on
			and first column (A) as 0 and second column (B) as 1 and so on*/

            // insert data for Event name.
            // Create object of SimpleDateFormat class and decide the format
            DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");


            //get current date time with Date()
            Date date = new Date();


            // Now format the date
            String date1 = dateFormat.format(date);

            cell = sheet.getRow(i).getCell(0);
            cell.setCellType(CellType.STRING);
            //driver.findElement(By.xpath("//input[@placeholder='Event Name']")).clear();
            driver.findElement(By.xpath("//input[@placeholder='Event Name']")).sendKeys(cell.getStringCellValue() + date1);

            // insert data for Host name
            cell = sheet.getRow(i).getCell(1);
            cell.setCellType(CellType.STRING);
            //driver.findElement(By.xpath("//input[@placeholder='Host Name']")).clear();
            driver.findElement(By.xpath("//input[@placeholder='Host Name']")).sendKeys(cell.getStringCellValue());

            //insert date
            cell = sheet.getRow(i).getCell(2);
            cell.setCellType(CellType.STRING);
            //driver.findElement(By.xpath("//input[@placeholder='DD/MM/YYYY']")).clear();
            driver.findElement(By.xpath("//input[@placeholder='DD/MM/YYYY']")).sendKeys(cell.getStringCellValue());

            //insert time
            cell = sheet.getRow(i).getCell(3);
            cell.setCellType(CellType.STRING);
            //driver.findElement(By.xpath("//input[@placeholder='DD/MM/YYYY']")).clear();
            driver.findElement(By.xpath("//input[@placeholder='Event Time']")).sendKeys(cell.getStringCellValue(), Keys.DOWN);

            //select Event Organizer
            cell = sheet.getRow(i).getCell(4);
            cell.setCellType(CellType.STRING);
            driver.findElement(By.xpath("//input[@placeholder='Select']")).sendKeys(cell.getStringCellValue());
            //WebElement eventorg = driver.findElement(By.xpath("//input[@placeholder='Select']"));
            //Select dropdown= new Select(eventorg);
            //dropdown.selectByVisibleText("Ronak Patel");

            //add survey URl
            cell = sheet.getRow(i).getCell(5);
            cell.setCellType(CellType.STRING);
            driver.findElement(By.xpath("//input[@placeholder='Survey URL']")).sendKeys(cell.getStringCellValue());

            //add Venue
            cell = sheet.getRow(i).getCell(6);
            cell.setCellType(CellType.STRING);
            driver.findElement(By.xpath("//input[@placeholder='Venue']")).sendKeys(cell.getStringCellValue());

            //add City
            cell = sheet.getRow(i).getCell(7);
            cell.setCellType(CellType.STRING);
            driver.findElement(By.xpath("//input[@placeholder='City']")).sendKeys(cell.getStringCellValue());

            //add State
            cell = sheet.getRow(i).getCell(8);
            cell.setCellType(CellType.STRING);
            driver.findElement(By.xpath("//input[@placeholder='State']")).sendKeys(cell.getStringCellValue());

            //add Country
            cell = sheet.getRow(i).getCell(9);
            cell.setCellType(CellType.STRING);
            driver.findElement(By.xpath("//input[@placeholder='Country']")).sendKeys(cell.getStringCellValue());

            //add Zip Code
            cell = sheet.getRow(i).getCell(10);
            cell.setCellType(CellType.STRING);
            driver.findElement(By.xpath("//input[@placeholder='Zip Code']")).sendKeys(cell.getStringCellValue());

            //add Custom field
            //cell = sheet.getRow(i).getCell(11);
            //cell.setCellType(CellType.STRING);
            //driver.findElement(By.xpath("//li[contains(text(),'Occupation')]")).sendKeys(cell.getStringCellValue());

           /* WebDriverWait wait = new WebDriverWait(driver, 10);
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='chosen-choices form-control rounded-0']")));*/


            //driver.findElement(By.xpath("//ul[@class='chosen-choices form-control rounded-0']")).click();
            //driver.findElement(By.xpath("//span[contains(text(),'Occupation')]")).click();
            //Select dropdown= new Select(eventorg);
            //dropdown.selectByIndex(2);
            Thread.sleep(3000);


            //click on submit
            driver.findElement(By.xpath("//button[@class='btn btn-primary btn-sm pull-right mb-2 mb-sm-0']")).click();


            // To click on Login button
            //driver.findElement(By.xpath("//input[@type='submit'][@id='u_0_5']")).click();
            //To write data in the excel
            FileOutputStream fos = new FileOutputStream(src);
            // Message to be written in the excel sheet
            String message = "Pass";
            // Create cell where data needs to be written.
            sheet.getRow(i).createCell(12).setCellValue(message);

            // finally write content
            workbook.write(fos);
            // close the file
            fos.close();


        }
    }
}
