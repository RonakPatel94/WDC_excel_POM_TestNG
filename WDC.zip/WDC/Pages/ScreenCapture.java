package WDC.Pages;

import WDC.Test.Login_Test;
import org.apache.poi.openxml4j.opc.internal.FileHelper;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenCapture{
    private static FileHelper FileUtils;
    private static Object driver;

    //private  Object driver;


    public ScreenCapture(WebDriver driver) {
        this.driver = driver;
    }

    public static void passScreenCapture() throws IOException
    {
        Date d = new Date();
        System.out.println(d.toString());

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");         // Your each screenshot will be taken as this format "Year-Month-Date-Hours-Minutes-Seconds"
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileHelper.copyFile(scrFile,  new File("D:\\Automation\\Automation_Practice\\Basic_Automation\\resources\\PassScreenshot"+sdf.format(d)+".png"));      //your screenshot path and convert date string to SimpleDateFormat because windows can't capture screenshot with(:)
    }

    public static void failScreenCapture() throws IOException
    {
        Date d = new Date();
        System.out.println(d.toString());

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HHmmss");
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        // Now you can do whatever you need to do with it, for example copy somewhere
        FileUtils.copyFile(scrFile, new File("D:\\Automation\\Automation_Practice\\Basic_Automation\\resources\\FailScreenshot\\"+sdf.format(d)+".png"));

    }

}
