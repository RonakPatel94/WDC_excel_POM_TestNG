package WDC.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.awt.image.DataBufferDouble;
import java.io.*;
import java.util.Properties;
import java.util.logging.LogManager;

public class CreateEvent_Page {
    WebDriver driver;
    LogManager prop;
    LogManager properties;


    //Xpath of all control
    By btncreateevent = By.xpath("//span[contains(text(),'Create Event')]");
    //By txteventname = By.xpath("//input[@placeholder='Event Name']");
    By txthostname = By.xpath("//input[@placeholder='Host Name']");
    By txtcalender = By.xpath("//input[@placeholder='DD/MM/YYYY']");
    By txteventtime = By.xpath("//input[@placeholder='Event Time']");

    public CreateEvent_Page(WebDriver driver) {
        this.driver = driver;
    }

    public static void readproperties() throws Exception  {
        BufferedReader reader = new BufferedReader(new FileReader("D:\\Automation\\Automation_Practice\\Basic_Automation\\src\\WDC\\Data\\WDC_DataFile.properties"));
        Properties prop = new Properties();
        prop.load(reader);
        System.out.println("The print details is "+prop);
        try {
            prop.load(reader);
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }

  /*  public void loadPropertiesFile()
    {
        File file = new File("D:\\Automation\\Automation_Practice\\Basic_Automation\\src\\WDC\\Data\\WDC_DataFile.properties");
        FileInputStream fileInput = null;
        try {
            fileInput = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //load properties file
        Properties prop = new Properties();
        try {
            assert fileInput != null;
            prop.load(fileInput);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }*/

    public void btncreateevent() {

        driver.findElement(btncreateevent).click();

    }

  /*  public void geteventname() {
        //driver.findElement(txteventname).sendKeys(properties.getProperty("eventname"));
        //driver.findElement(txteventname).sendKeys(prop.getProperty("eventname"));

        driver.findElement(By.xpath("//input[@placeholder='Event Name']")).sendKeys(prop.getProperty("Event"));
    }*/

    public void gethostname() {
        //driver.findElement(txthostname).sendKeys(prop.getProperty(Hostname));

        driver.findElement(By.xpath("//input[@placeholder='Host Name']")).sendKeys(prop.getProperty("Hostname"));
    }

    public void getCalender() {
        //driver.findElement(txtcalender).sendKeys(prop.getProperty(eventDate));
        driver.findElement(By.xpath(prop.getProperty("txtcalender"))).sendKeys(prop.getProperty("eventDate"));
    }

    public void getEventtime() {
        //driver.findElement(txteventtime).sendKeys(prop.getProperty(eventtime));
        driver.findElement(By.xpath(prop.getProperty("txteventtime"))).sendKeys(prop.getProperty("eventtime"));
    }

}



   /*public void addevent(String eventname,String Hostname,String eventDate,String eventtime)
   {
        geteventname(eventname);
        gethostname(Hostname);
        getCalender(eventDate);
        getEventtime(eventtime);
   }*/

