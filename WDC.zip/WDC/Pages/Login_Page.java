package WDC.Pages;

import org.apache.poi.openxml4j.opc.internal.FileHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class Login_Page {
    WebDriver driver;
    //initialise xpath
    By txtemail = By.xpath("//input[@placeholder='Email']");
    By txtpassword = By.xpath("//input[@placeholder='Password']");
    By signinbtn = By.xpath("//button[@class='btn loginBtn block full-width m-b disabledBtn']");
    By linkLogout = By.xpath("//a[contains(text(),'Log out')]");
    public FileHelper FileUtils;

    //driver constructor
    public Login_Page(WebDriver driver) {
        this.driver = driver;
    }

    //initialise set email
    public void SetEmail(String emailID) {
        driver.findElement(txtemail).sendKeys(emailID);
    }

    //initialise set password
    public void Setpassword(String password) {
        driver.findElement(txtpassword).sendKeys(password);
    }

    //initialise click on signin
    public void SigninClick() {
        driver.findElement(signinbtn).click();
    }
    //get text
    public String getPageTitle() {
        return driver.getTitle();
    }
    public void linkLogout() {
        driver.findElement(linkLogout).click();
    }

    public void loginpage(String emailID, String password) {
        // fill email
        SetEmail(emailID);

        // fill password
        Setpassword(password);

        // click on sign-in button
        SigninClick();
    }



}

