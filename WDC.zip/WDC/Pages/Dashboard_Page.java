package WDC.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Dashboard_Page {
    WebDriver driver;

    //locate elements //nav[@class='navbar-default navbar-static-side']/li
    By Totallink = By.xpath("//nav[@class='navbar-default navbar-static-side']/*");
    By menucollpase = By.xpath("//a[contains(@class,'navbar-minimalize minimalize-styl-2 btn btn-primary')]");
    By upcommingEvent = By.xpath("//div[@class='ibox']//div[@class='ibox-content']//tr//td");

    public Dashboard_Page(WebDriver driver) {
        this.driver = driver;
    }

    public void Totallink() {
        //driver.findElement(By.xpath(properties.getProperty(btnMyPersonalInformation))).click();
        String Total = driver.findElement(Totallink).getText();
        System.out.println("Total List of Menu :-" + "\n" + Total + "\n--------");

    }

    //Read upcomming event details
    public void UpcommingEvent() {
       /*
        String Upcommingevent = driver.findElement(upcommingEvent).getText();
        System.out.println("Total Upcomming Event :-"+"\n" +Upcommingevent);*/

        WebElement f = driver.findElement(By.xpath("//div[@class='ibox']//div[@class='table-responsive']"));
        List rows = f.findElements(By.tagName("tr"));
        System.out.println("Number of rows=" + rows.size());
        List columns = f.findElements(By.tagName("td"));
        System.out.println("Number of columns=" + columns.size());
        System.out.println(f.getText());
    }
}



