package WDC.Test;
import WDC.Pages.Dashboard_Page;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class Dashboard_Test extends Login_Test{
    Dashboard_Page obj;


    @BeforeMethod
    public void setupDashboard() {
        obj = new Dashboard_Page(driver);
    }
    @Test
    public void Dashboard() throws IOException {
        obj = new Dashboard_Page(driver);

        //objMPI.Datafile();
        obj.Totallink();
        obj.UpcommingEvent();
    }
}
