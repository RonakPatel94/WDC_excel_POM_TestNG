package WDC.Test;

import WDC.Pages.CreateEvent_Page;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class CreateEvent_Test extends Login_Test {

    CreateEvent_Page obj;

    @BeforeMethod
    public void setupEvent() {

        obj = new CreateEvent_Page(driver);
    }

    @Test
    public void CreateEvent() throws IOException{
        obj = new CreateEvent_Page(driver);
        //obj.readproperties();
        obj.btncreateevent();
        //obj.geteventname();
        obj.gethostname();
        obj.getCalender();
        obj.getEventtime();


    }
}