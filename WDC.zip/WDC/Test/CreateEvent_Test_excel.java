package WDC.Test;

import WDC.Pages.CreateEvent_Page;
import WDC.Pages.CreateEvent_Page_excel;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.ITestResult;
import org.testng.internal.Utils;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class CreateEvent_Test_excel extends Login_Test {
    CreateEvent_Page_excel obj;

    @BeforeMethod
    public void setupEvent() {

        obj = new CreateEvent_Page_excel(driver);
    }

    @Test
    public void CreateEvent() throws IOException {
        try {
            //obj = new CreateEvent_Page_excel(driver);

            obj.btncreateevent();
            obj.ReadData();
        } catch (InterruptedException e) {
            e.printStackTrace();

        }
    }
}


