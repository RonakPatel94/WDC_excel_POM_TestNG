package WDC.Test;

import WDC.Pages.Login_Page;
import WDC.Pages.ScreenCapture;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.Augmenter;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.internal.Utils;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class Login_Test {
    public WebDriver driver;
    Login_Page obj;
    public Utils FileUtils;

    @BeforeClass
    public void setup() {

        // Define Chrome Driver
        System.setProperty("webdriver.chrome.driver", "resources\\chromedriver.exe");
        driver = new ChromeDriver();

        // maximize the browser
        driver.manage().window().maximize();

        // set Implicit wait
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

    }

    @BeforeMethod
    @Parameters({"appURL", "emailID", "password"})
    public void CheckLogin(String appURL, String emailID, String password) throws Exception {
        //initialise browser
        driver.get(appURL);

        //Create Login Page object
        obj = new Login_Page(driver);

        //login to application
        obj.loginpage(emailID, password);
        //obj.SigninClick();

        //Verify login page title
        try {
            String actualLoginPageTitle = obj.getPageTitle();
            Assert.assertEquals(actualLoginPageTitle, "West Star Events");
            //ScreenCapture.passScreenCapture();     //classname.methodname

        } catch (AssertionError e) {
              //classname.methodname
           // ScreenCapture.failScreenCapture();
            System.out.println("User is not able to Login");
            throw e;
        }
        System.out.println("Successfully Login");
    }

    @AfterMethod
    public void checkLogOut() {
        //logout from application

        obj.linkLogout();
    }

   /* @AfterClass
    public void teardown() {
        // Close browser
        driver.quit();
    }*/
}