package WDC.Test;
import WDC.Pages.ScreenCapture;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class ScreenCaptureTest extends Login_Test {
    ScreenCapture obj;
    @BeforeMethod
    public void setupEvent() {

        obj = new ScreenCapture(driver);
    }
    @Test
    public void Screenshot() throws IOException {
        obj = new ScreenCapture(driver);
        obj.failScreenCapture();
        obj.passScreenCapture();
    }
}
